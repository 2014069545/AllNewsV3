
public class profilesetget {

	private String lname;
	private String fname;
	private String about;
	private String email;
	private String user;
	private String pass;
	
	
	public String getLname() {
		return lname;
	}
	public void setLname(String last) {
		lname = last;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String first) {
		fname = first;
	}
	public String getAbout() {
		return about;
	}
	public void setAbout(String abt) {
		about = abt;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String mail) {
		email = mail;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String usr) {
		user = usr;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pss) {
		pass = pss;
	}
	
	
	
}
