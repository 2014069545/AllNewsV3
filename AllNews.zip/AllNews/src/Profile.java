

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ProfileSetGet
 */
@WebServlet("/Profile")
public class Profile extends HttpServlet {
	private static final long serialVersionUID = 1L;

	profilesetget person;
	
    public Profile() {
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		CreateApplication(request,response);
		
		out.println("<html>");
		
		out.println("<div style =background-image:url(newsbg.jpg); color:black; padding:0.8px;>");
		out.println("<h1 style = font-family:courier new>");
		out.println("AllNews");
		out.println("</h1>");
		out.println("<div>");
		
		out.println("<div style=background-color:grey; color:black; padding:0.8px;>");
		out.println("<h2 style=font-family:courier>");
		out.println("<img src=C:/Users/o.parra/Desktop/edij/eclipseproj/AllNews/WebContent/jreyes.jpg style=width:90px;height:90px;>");
		out.println(person.getFname() + person.getLname()+ "       " +person.getUser());
		out.println("</h2>");
		out.println("</div>");
		
		out.println("<div style=background-color:grey; color:black; padding:0.8px;>");
		out.println("<p style=font-family:courier;>");
		out.println(person.getAbout());
		out.println("</p>");
		out.println("</div>");
		
		out.println("<div style=background-image: url(newsbg.jpg); color:black; padding:0.3px;>");
		out.println("<h3 style=font-family:courier;>COMMENTS</h3>");
		out.println("</div>");

		out.println("<p style=font-family:courier;>");
		out.println("<img src=C:/Users/o.parra/Desktop/edij/eclipseproj/AllNews/WebContent/du30.jpg style=width:50px;height:50px;>");
		out.println("Duterte will not apologize");
		out.println("</p>");
		
		out.println("<p style=font-family:courier;>");
		out.println("- This is a very sensitive issue! Hindi dapat nagjojoke sa mga bagay na yan. #notoDU30");
		out.println("</p>");
		
		out.println("<div style=background-image: url(newsbg.jpg); color:black; padding:0.3px;>");
		out.println("<h3 style=font-family:courier;>BOOKMARKS</h3>");
		out.println("</div>");

		out.println("<p style=font-family:courier;>");
		out.println("<img src=C:/Users/o.parra/Desktop/edij/eclipseproj/AllNews/WebContent/du30.jpg style=width:50px;height:50px;>");
		out.println("Duterte will not apologize");
		out.println("</p>");
		
		out.println("<p style=font-family:courier;>");
		out.println("Read More");
		out.println("</p>");
		
		out.println("<div style=background-image: url(newsbg.jpg); color:black; padding:0.3px;>");
		out.println("<h3 style=font-family:courier;>WRITERS</h3>");
		out.println("</div>");

		out.println("<p style=font-family:courier;>");
		out.println("<img src=C:/Users/o.parra/Desktop/edij/eclipseproj/AllNews/WebContent/du30.jpg style=width:50px;height:50px;>");
		out.println("Jacob Sy");
		out.println("</p>");
		
		out.println("<p style=font-family:courier;>");
		out.println("Read More");
		out.println("</p>");

		out.println("</html>");

	}
	private void CreateApplication(HttpServletRequest request,
			HttpServletResponse response) {
		// TODO Auto-generated method stub
		
		person = new profilesetget();
		person.setLname(request.getParameter("lname"));
		person.setFname(request.getParameter("fname"));
		person.setAbout(request.getParameter("about"));
		person.setEmail(request.getParameter("email"));
		person.setUser(request.getParameter("user"));
		person.setPass(request.getParameter("pass"));
		
	}
}